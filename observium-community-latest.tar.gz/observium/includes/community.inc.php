<?php

// stub functions for not exist features
function get_type_groups()    { return array(); }
function get_groups_by_type() { return array(); }
function get_group_entities() { return array(); }

// EOF
