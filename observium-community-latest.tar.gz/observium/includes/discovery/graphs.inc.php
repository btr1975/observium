<?php

/**
 * Observium
 *
 *   This file is part of Observium.
 *
 * @package    observium
 * @subpackage discovery
 * @copyright  (C) 2006-2013 Adam Armstrong, (C) 2013-2016 Observium Limited
 *
 */

// Discover arbitrary graphs by MIB

$include_dir = "includes/discovery/graphs/";
include("includes/include-dir-mib.inc.php");

// EOF
